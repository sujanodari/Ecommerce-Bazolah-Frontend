self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "71b423b66d45e742a23f996727791014",
    "url": "/index.html"
  },
  {
    "revision": "4227197e3ed5b98801bf",
    "url": "/static/css/2.ecb5f83e.chunk.css"
  },
  {
    "revision": "125fedf173e8b1521a9f",
    "url": "/static/css/main.586b1083.chunk.css"
  },
  {
    "revision": "4227197e3ed5b98801bf",
    "url": "/static/js/2.60124038.chunk.js"
  },
  {
    "revision": "0bf38cf6c0b51ec69d7a52e8875a6dbf",
    "url": "/static/js/2.60124038.chunk.js.LICENSE.txt"
  },
  {
    "revision": "125fedf173e8b1521a9f",
    "url": "/static/js/main.b8d25006.chunk.js"
  },
  {
    "revision": "60ef33e92ece8d905977",
    "url": "/static/js/runtime-main.3cd1cd78.js"
  }
]);